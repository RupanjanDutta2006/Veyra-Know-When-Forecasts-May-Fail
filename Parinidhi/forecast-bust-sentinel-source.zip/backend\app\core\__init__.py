"""Core configuration package."""
